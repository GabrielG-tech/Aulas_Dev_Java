package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    @Test
    void somaMatriz() {
        Calculadora calc = new Calculadora();
        assertEquals(110, calc.somar(60,50));
    }

    @Test
    void subtracaoMatriz() {
        Calculadora calc = new Calculadora();
        assertEquals(10, calc.subtrair(60,50));
    }

    @Test
    void multMatriz() {
        Calculadora calc = new Calculadora();
        assertEquals(41, calc.multiplicar(2,3,5,7));
    }
}